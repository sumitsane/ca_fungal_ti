import pandas as pd

# Step 1: Load Orthogroups.tsv
ortho_df = pd.read_csv("Orthogroups.tsv", sep="\t")

# Step 2: Count number of genes in each cell
gene_count_df = ortho_df.copy()
protein_cols = [col for col in ortho_df.columns if col.endswith("_proteins")]

for col in protein_cols:
    gene_count_df[col] = gene_count_df[col].fillna("").apply(lambda x: len(str(x).split()))

# Step 3: Save to CSV
gene_count_df.set_index("Orthogroup", inplace=True)
gene_count_df[protein_cols].to_csv("orthogroup_gene_counts.csv")

print("✅ Saved: orthogroup_gene_counts.csv")

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# === Step 1: Load the gene count matrix ===
og_gene_counts = pd.read_csv("orthogroup_gene_counts.csv", index_col=0)  # Replace with actual file name

# === Step 2: Define protein columns (species) ===
species_cols = [col for col in og_gene_counts.columns if col.endswith("_proteins")]

# === Step 3: Filter orthogroups with at least 1 gene in any species ===
og_gene_counts_filtered = og_gene_counts[og_gene_counts[species_cols].sum(axis=1) > 0]

# === Step 4: Prepare a smaller set (e.g. Top 50 most variable orthogroups) ===
top_ogs = og_gene_counts_filtered[species_cols].var(axis=1).nlargest(50).index
log_counts_subset = og_gene_counts_filtered.loc[top_ogs, species_cols].applymap(lambda x: np.log2(x + 1))

# === Step 5: Plot small heatmap for visualization ===
plt.figure(figsize=(10, 0.4 * len(log_counts_subset)))  # scalable height
sns.heatmap(
    log_counts_subset,
    cmap="YlOrRd",
    linewidths=0.4,
    linecolor="gray",
    annot=False,
    fmt=".1f",
    cbar_kws={"label": "log2(Gene Count + 1)"}
)
plt.title("Top 50 Variable Orthogroups by Gene Count (log2 scale)")
plt.xlabel("Species")
plt.ylabel("Orthogroup")
plt.tight_layout()
plt.show()

# === Step 6: Save full heatmap to file (optional for publication) ===
log_counts_full = og_gene_counts_filtered[species_cols].applymap(lambda x: np.log2(x + 1))
plt.figure(figsize=(10, 0.02 * len(log_counts_full)))  # dynamic size for full table
sns.heatmap(
    log_counts_full,
    cmap="YlOrRd",
    linewidths=0.1,
    linecolor="gray",
    cbar_kws={"label": "log2(Gene Count + 1)"}
)
plt.title("All Orthogroups Gene Copy Numbers Across Species")
plt.xlabel("Species")
plt.ylabel("Orthogroup")
plt.tight_layout()
plt.savefig("heatmap_all_orthogroups.pdf", format="pdf")
print("✅ Saved full heatmap to heatmap_all_orthogroups.pdf")
