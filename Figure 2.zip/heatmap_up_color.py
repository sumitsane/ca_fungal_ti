import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from difflib import get_close_matches

print("🔧 Starting corrected eIF analysis pipeline...")

# === Step 1: Load eIF reference list ===
eif_df = pd.read_csv("eiflist.csv", encoding="utf-8")
eif_df.columns = [col.strip().replace('\ufeff', '') for col in eif_df.columns]

# Use combined column for eIF family (Factor + subunit)
if "Factor" in eif_df.columns and "subunit" in eif_df.columns:
    eif_df["Factor subunit"] = eif_df["Factor"].astype(str).str.strip() + " " + eif_df["subunit"].astype(str).str.strip()

# Extract relevant columns
sys_col = get_close_matches("Systematic name", eif_df.columns, n=1)[0]
fac_col = get_close_matches("Factor subunit", eif_df.columns, n=1)[0]

# Extract eIF family identifiers
eif_df["eif_family"] = eif_df[fac_col].str.extract(r"(eIF\d+[A-Z]?)", expand=False)
eif_df = eif_df.dropna(subset=["eif_family"])
gene_to_eif = dict(zip(eif_df[sys_col].str.strip(), eif_df["eif_family"]))

print(f"🧬 {len(gene_to_eif)} eIF genes loaded from list.")

# === Step 2: Parse Orthogroups.txt ===
gene_to_og = {}
with open("Orthogroups.txt", "r", encoding="utf-8") as f:
    for line in f:
        if ":" not in line:
            continue
        og_id, genes_str = line.strip().split(":", 1)
        for gene in genes_str.strip().split():
            gene_to_og[gene] = og_id

print(f"📦 {len(gene_to_og)} genes mapped to orthogroups.")

# === Step 3: Load Orthogroups.tsv for species mapping ===
ortho_df = pd.read_csv("Orthogroups.tsv", sep="\t")
species_cols = [col for col in ortho_df.columns if col.endswith("_proteins")]

# Build OG-to-species-gene dictionary
og_species = {}
for _, row in ortho_df.iterrows():
    og_id = row["Orthogroup"]
    og_species[og_id] = {}
    for sp in species_cols:
        genes = str(row[sp]).split() if pd.notna(row[sp]) else []
        og_species[og_id][sp] = genes

# === Step 4: Count eIF family genes per species + Track OGs ===
eif_counts = {}
eif_to_og = {}  # eIF → OG

for gene, eif in gene_to_eif.items():
    matching_ogs = [og for og, sp_genes in og_species.items()
                    if gene in sp_genes.get("cerevisiae_S288C_proteins", [])]

    for og in matching_ogs:
        eif_to_og[eif] = og  # Save the first match
        if eif not in eif_counts:
            eif_counts[eif] = {sp: 0 for sp in species_cols}
        for sp in species_cols:
            eif_counts[eif][sp] += len(og_species[og].get(sp, []))

# === Step 5: Output table with dual labels ===
heatmap_df = pd.DataFrame(eif_counts).T.fillna(0).astype(int)
heatmap_df.index.name = "eIF Family"

# Add OG IDs to labels if known
heatmap_df.index = [
    f"{eif} ({eif_to_og[eif]})" if eif in eif_to_og else eif
    for eif in heatmap_df.index
]

heatmap_df.to_csv("corrected_eif_family_gene_counts_with_og.csv")
print("\n✅ Final eIF counts saved to corrected_eif_family_gene_counts_with_og.csv")
print(heatmap_df)

# === Step 6: Heatmap plot ===
if not heatmap_df.empty:
    plt.figure(figsize=(10, 0.5 * len(heatmap_df)))
    sns.heatmap(
        heatmap_df,
        annot=True,
        cmap="YlGnBu",
        linewidths=0.5,
        linecolor="gray"
    )
    plt.title("Corrected eIF Gene Presence per Species (eIF Name + Orthogroup ID)")
    plt.xlabel("Species")
    plt.ylabel("eIF Family (Orthogroup)")
    plt.tight_layout()
    plt.savefig("corrected_eif_heatmap_with_og.png", dpi=300)
    plt.show()
else:
    print("⚠️ No eIF gene matches found in corrected mapping.")
