import os
import shutil
import subprocess
from Bio import SeqIO
import sys

def check_executable(name):
    if shutil.which(name) is None:
        print(f"❌ ERROR: Required program '{name}' not found in PATH.")
        sys.exit(1)

# --- Check environment ---
check_executable("mafft")
check_executable("FastTree")
check_executable("codeml")
check_executable("perl")  # for pal2nal.pl

if not os.path.exists("pal2nal.pl"):
    print("❌ ERROR: pal2nal.pl is missing. Download it and place in the working directory.")
    sys.exit(1)

# --- Input files ---
prot_fasta = "fixed_proteins.faa"
cds_fasta = "all_CDS.fna"

if not os.path.exists(prot_fasta) or not os.path.exists(cds_fasta):
    print("❌ ERROR: Missing all_proteins.faa or all_CDS.fna")
    sys.exit(1)

# --- Updated Gene dictionary ---
target_genes = {
    "eIF1": {
        "B11221": "CJI97_001041-T",
        "B8441": "B9J08_001021-T",
        "C_albicans": "CJI97_000694-T"
    },
    "eIF2alpha": {
        "B11221": "CJI97_000502-T",
        "B8441": "B9J08_000501-T",
        "C_albicans": "CJI97_005158-T"
    },
    "DOM34": {
        "B11221": "CJI97_002048-T",
        "B8441": "B9J08_002503-T",
        "C_albicans": "CJI97_000603-T"
    },
 # ✅ NEW GENES ADDED
    "eIF1A": {
        "C_auris_B8441": "B9J08_000839-T",
        "C_auris_B11221": "CJI97_000857-T",
        "C_albicans": None,  # optional if you want to include
        "S_cerevisiae": "YMR260C"
    },
    "eIF2gamma": {
        "C_auris_B8441": "B9J08_003238-T",
        "C_auris_B11221": "CJI97_003313-T",
        "C_albicans": "C1_00590W_B-T",
        "S_cerevisiae": "YOR259C"
    },
    "eIF4A": {
        "C_auris_B8441": "B9J08_000996-T",
        "C_auris_B11221": "CJI97_001015-T",
        "C_albicans": "CR_09740W_B-T",
        "S_cerevisiae": "YKR059W"
    }

}

prot_records = SeqIO.to_dict(SeqIO.parse(prot_fasta, "fasta"))
cds_records = SeqIO.to_dict(SeqIO.parse(cds_fasta, "fasta"))

for gene, mapping in target_genes.items():
    print(f"\n🔬 Processing {gene}")
    outdir = f"output/{gene}"
    os.makedirs(outdir, exist_ok=True)

    prot_out, cds_out = [], []

    for species, gid in mapping.items():
        if gid in prot_records:
            p = prot_records[gid]
            p.id = f"{species}|{gid}"
            p.description = ""
            prot_out.append(p)
        else:
            print(f"⚠️ WARNING: Protein ID {gid} not found in {prot_fasta}")

        if gid in cds_records:
            c = cds_records[gid]
            c.id = f"{species}|{gid}"
            c.description = ""
            cds_out.append(c)
        else:
            print(f"⚠️ WARNING: CDS ID {gid} not found in {cds_fasta}")

    if len(prot_out) < 3 or len(cds_out) < 2:
        print(f"❌ Skipping {gene}: fewer than 2 sequences found.")
        continue

    SeqIO.write(prot_out, f"{outdir}/prot.faa", "fasta")
    SeqIO.write(cds_out, f"{outdir}/cds.fna", "fasta")

    aligned_prot = f"{outdir}/aligned_prot.faa"
    with open(aligned_prot, "w") as out:
        subprocess.run(["mafft", "--auto", f"{outdir}/prot.faa"], stdout=out)

    if not os.path.exists(aligned_prot):
        print(f"❌ ERROR: MAFFT alignment failed for {gene}")
        continue

    codon_aln = f"{outdir}/codon_aln.phy"
    with open(codon_aln, "w") as out:
        subprocess.run(["perl", "pal2nal.pl", aligned_prot, f"{outdir}/cds.fna", "-output", "paml"], stdout=out)

    if not os.path.exists(codon_aln):
        print(f"❌ ERROR: pal2nal failed for {gene}")
        continue

    tree_file = f"{outdir}/tree.nwk"
    with open(tree_file, "w") as out:
        subprocess.run(["FastTree", "-quiet", aligned_prot], stdout=out)

    if not os.path.exists(tree_file):
        print(f"❌ ERROR: FastTree failed for {gene}")
        continue

    ctl_file = f"{outdir}/codeml.ctl"
    with open(ctl_file, "w") as f:
        f.write(f"""seqfile = codon_aln.phy
treefile = tree.nwk
outfile = results.txt

      noisy = 9
    verbose = 1
    runmode = 0

    seqtype = 1
  CodonFreq = 2
      clock = 0
      model = 0
   NSsites = 0
      icode = 0
  fix_kappa = 0
      kappa = 2
  fix_omega = 0
      omega = 1
  cleandata = 1
""")

    try:
        result = subprocess.run(["codeml", "codeml.ctl"], cwd=outdir, capture_output=True, text=True, timeout=60)
        if result.returncode != 0:
            print(f"❌ codeml failed for {gene}")
            print(result.stderr)
        else:
            print(f"✅ Finished {gene} → {outdir}/results.txt")
    except Exception as e:
        print(f"❌ ERROR: codeml crashed for {gene}: {e}")
