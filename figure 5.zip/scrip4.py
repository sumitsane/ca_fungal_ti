import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from gprofiler import GProfiler

# Step 1: Load DEGs from RNA-seq Excel file
de_results = pd.read_excel("GSE271513_RNAseq_data.xlsx", sheet_name="C_auris_200µM_vs_100µM_HSL")

# Step 2: Filter for significant DEGs
sig_degs = de_results[(de_results['P_adj'] < 0.05) & (de_results['Log FC'].abs() > 1)].copy()
print(f"Significant DEGs: {len(sig_degs)} genes")

# ✅ Clean DEG gene identifiers (remove 'gene:' prefix)
sig_degs['Gene ID'] = sig_degs['Gene ID'].str.replace(r'^gene:', '', regex=True)

# Step 3: Load eggNOG annotation file for C. auris B8441
file_path = "out.emapper_cauris8441.annotations"

# Extract header
header = None
with open(file_path, 'r') as f:
    for line in f:
        if line.startswith('#query'):
            header = line.strip('#').strip().split('\t')
            break

if header is None:
    raise ValueError("Header line starting with '#query' not found in the annotation file.")

# Load annotation data
cauris_ann = pd.read_csv(file_path, sep='\t', comment='#', names=header)

# Step 4: Extract gene-to-ortholog mapping
mapping_df = cauris_ann[['query', 'Preferred_name']].dropna()
mapping_df.columns = ['C_auris_gene', 'ortholog_symbol']

# ✅ Clean annotation gene IDs (remove .t1/.t2 if present)
mapping_df['C_auris_gene'] = mapping_df['C_auris_gene'].str.replace(r'\.t\d+$', '', regex=True)

# Step 5: Merge DEGs with orthologs
mapped_degs = pd.merge(sig_degs, mapping_df, left_on='Gene ID', right_on='C_auris_gene', how='inner')
mapped_degs.dropna(subset=['ortholog_symbol'], inplace=True)

# Step 6: Extract unique orthologs
ortholog_genes = mapped_degs['ortholog_symbol'].unique().tolist()
print(f"Mapped orthologs for enrichment: {len(ortholog_genes)} genes")

# Step 7: Run enrichment with g:Profiler
if not ortholog_genes:
    raise ValueError("No orthologs found. Check identifier formats or annotation completeness.")

gp = GProfiler(return_dataframe=True)
enrichment = gp.profile(organism='scerevisiae', query=ortholog_genes)

# Step 8: Filter and summarize top terms (GO, KEGG, Reactome)
sources = ["GO:BP", "GO:MF", "GO:CC", "KEGG", "REAC"]
top_terms = (
    enrichment[enrichment["source"].isin(sources)]
    .sort_values("p_value")
    .groupby("source")
    .head(5)
    .copy()
)

# Calculate gene ratio and -log10(p-value)
top_terms["Gene Ratio"] = top_terms["intersection_size"] / top_terms["effective_domain_size"]
top_terms["-log10(p-value)"] = -np.log10(top_terms["p_value"])

# Label sources
source_labels = {
    "GO:BP": "GO: Biological Process",
    "GO:MF": "GO: Molecular Function",
    "GO:CC": "GO: Cellular Component",
    "KEGG": "KEGG Pathway",
    "REAC": "Reactome Pathway"
}
top_terms["Category"] = top_terms["source"].map(source_labels)

# Step 9: Plot dot plot
plt.figure(figsize=(12, 8))
sns.scatterplot(
    data=top_terms,
    x="-log10(p-value)",
    y="name",
    size="Gene Ratio",
    hue="Category",
    palette="Set2",
    sizes=(50, 300),
    legend="brief"
)

plt.xlabel("-log₁₀(p-value)")
plt.ylabel("Enriched Term")
plt.title("Top Enriched Terms (GO, KEGG, Reactome)")
plt.legend(bbox_to_anchor=(1.05, 1), loc="upper left", title="Category / Size = Gene Ratio")
plt.tight_layout()
plt.savefig("dotplot_enrichment.png", dpi=300)
plt.show()

# Step 10: Save summary table (CSV and LaTeX)
print("Available columns:", top_terms.columns.tolist())


print("Available columns:", top_terms.columns.tolist())

# Use 'term_id' only if it exists
columns_to_use = ['source', 'name', 'p_value', 'intersection_size', 'effective_domain_size', 'description', 'Gene Ratio']
if 'term_id' in top_terms.columns:
    columns_to_use.insert(2, 'term_id')  # Insert after 'name'

# Extract summary table safely
summary_table = top_terms[columns_to_use].copy()

# Rename columns
column_renames = {
    "source": "Source",
    "name": "Term",
    "p_value": "p-value",
    "intersection_size": "Genes in Term",
    "effective_domain_size": "Total Genes",
    "description": "Description",
    "Gene Ratio": "Gene Ratio"
}
if 'term_id' in top_terms.columns:
    column_renames['term_id'] = "ID"

summary_table.rename(columns=column_renames, inplace=True)

# Save outputs
summary_table.sort_values("p-value", inplace=True)
summary_table.to_csv("enrichment_summary_table.csv", index=False)
summary_table.to_latex(
    "enrichment_summary_table.tex",
    index=False,
    float_format="%.2e",
    caption="Top enriched terms with gene ratio from GO, KEGG, and Reactome using S. cerevisiae orthologs.",
    label="tab:dotplot_enrichment"
)





