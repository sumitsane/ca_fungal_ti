import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# === Load EIF gene list ===
eif_df = pd.read_csv("eiflist.csv")
eif_df.columns = eif_df.columns.str.strip()
eif_df = eif_df.astype(str).apply(lambda x: x.str.strip())  # Clean whitespace

# Extract relevant sets
systematic_names = set(eif_df['Systematic name'])
systematic_to_factor = dict(zip(eif_df['Systematic name'], eif_df['Factor']))

print("✅ Loaded EIF gene list. Sample systematic names:", list(systematic_names)[:5])

# === Load Orthogroups ===
ortho = pd.read_csv("Orthogroups.tsv", sep="\t")
ortho.columns = ortho.columns.str.strip()

sc_col = "cerevisiae_S288C_proteins"
b8441_col = "auris_B8441_proteins"

b8441_eif_genes = set()
b8441_to_sc = {}
b8441_to_factor = {}

for _, row in ortho.iterrows():
    if pd.notna(row.get(sc_col)) and pd.notna(row.get(b8441_col)):
        sc_genes = [g.strip() for g in row[sc_col].split(',')]
        b8441_genes = [g.strip() for g in row[b8441_col].split(',')]
        
        for sc in sc_genes:
            if sc in systematic_names:
                factor = systematic_to_factor.get(sc, '?')
                for bg in b8441_genes:
                    b8441_eif_genes.add(bg)
                    b8441_to_sc[bg] = sc
                    b8441_to_factor[bg] = factor

print(f"\n✅ Found {len(b8441_to_sc)} B8441 genes with EIF orthologs")
print("🔬 Sample: ", list(b8441_eif_genes)[:5])

# === Load expression matrix ===
expr = pd.read_csv("combined_expression_matrix.csv", index_col=0)
expr.index = expr.index.str.strip()

# Top 200 variable genes
top_var = expr.var(axis=1).sort_values(ascending=False).head(200).index
top_expr = expr.loc[top_var]

# Highlighted EIFs
highlight_genes = top_expr.index.intersection(b8441_eif_genes)

# Label top_expr index
top_labels = []
for gene in top_expr.index:
    if gene in b8441_to_sc:
        sc_sys = b8441_to_sc[gene]
        factor = b8441_to_factor.get(gene, '?')
        label = f"{gene} ({sc_sys} / {factor})"
    else:
        label = gene
    top_labels.append(label)
top_expr.index = top_labels

# === Plot heatmap for top 200 ===
g = sns.clustermap(top_expr, z_score=0, cmap='vlag', figsize=(10, 10))

for tick_label in g.ax_heatmap.get_yticklabels():
    label_text = tick_label.get_text().split(' ')[0]
    if label_text in highlight_genes:
        tick_label.set_color('red')
        tick_label.set_fontweight('bold')

plt.title("Top 200 Variable Genes (EIFs highlighted in red)", pad=100)
plt.show()

print("\n🧬 Highlighted EIF genes in heatmap:")
print(sorted(highlight_genes))

# === EIF-only heatmap ===
eif_found = expr.index.intersection(b8441_eif_genes)

if len(eif_found) == 0:
    print("⚠️ No EIF genes found in expression matrix.")
else:
    eif_expr = expr.loc[eif_found]
    eif_expr = eif_expr.loc[eif_expr.var(axis=1).sort_values(ascending=False).index]

    eif_labels = []
    for gene in eif_expr.index:
        sc_sys = b8441_to_sc.get(gene, '?')
        factor = b8441_to_factor.get(gene, '?')
        label = f"{gene} ({sc_sys} / {factor})"
        eif_labels.append(label)
    eif_expr.index = eif_labels

    g2 = sns.clustermap(eif_expr, z_score=0, cmap='coolwarm', figsize=(8, 10))
    plt.title("EIF-Related Genes (B8441 with S288C / EIF Factor)", pad=100)
    plt.show()
