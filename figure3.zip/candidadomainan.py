import pandas as pd
import matplotlib.pyplot as plt

# === FILE PATHS ===
orthogroups_file = "translation_initiation_orthogroups.tsv"
interpro_files = {
    "SC5314": "SC5314.tsv",
    "B8441": "B8441.tsv",
    "B11221": "B12211.tsv",
    
}

# === LOAD ORTHOGROUPS FILE ===
orthogroups_df = pd.read_csv(orthogroups_file, sep='\t')

# Create dictionary: species → list of eIF-related protein IDs
species_proteins = {
    "SC5314": orthogroups_df["albicans_SC5314_proteins"].dropna().tolist(),
    "B8441": orthogroups_df["auris_B8441_proteins"].dropna().tolist(),
    "B11221": orthogroups_df["auris_B11221_proteins"].dropna().tolist()

}

# === LOAD INTERPROSCAN FILES AND FILTER TO eIF PROTEINS ===
def load_and_filter(filepath, target_proteins):
    cols = [
        "protein_id", "md5", "length", "source", "signature", "desc",
        "start", "end", "score", "status", "date",
        "ipr_id", "ipr_desc", "go_terms", "pathways"
    ]
    df = pd.read_csv(filepath, sep='\t', header=None, names=cols)
    return df[df["protein_id"].isin(target_proteins) & df["ipr_desc"].notna()]

# === COLLECT DOMAINS ===
domain_summary = {}

for species, filepath in interpro_files.items():
    proteins = species_proteins[species]
    df = load_and_filter(filepath, proteins)
    domain_counts = df["ipr_desc"].value_counts()
    domain_summary[species] = domain_counts

# === COMBINE AND DISPLAY ===
summary_df = pd.DataFrame(domain_summary).fillna(0).astype(int)

# ✅ Remove placeholder or malformed domain labels
summary_df = summary_df[summary_df.index != "-"]

# Proceed as usual
summary_df['Total'] = summary_df.sum(axis=1)
summary_df = summary_df.sort_values(by='Total', ascending=False)

print("🧬 Top eIF-related InterPro domains across species:")
print(summary_df.head(15))

# === PLOT ===
top_n = 15
summary_df.head(top_n).drop(columns='Total').plot(kind='barh', figsize=(12, 8))
plt.title("Top eIF-Related InterPro Domains Across Candida Species")
plt.xlabel("Count")
plt.ylabel("InterPro Domain")
plt.gca().invert_yaxis()
plt.tight_layout()
plt.show()
